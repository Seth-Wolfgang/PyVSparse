This directory contains a script which will produce the redundancy heat maps.
The .npy files in the current directory contain the raw data necessary to
generate the redundancy heatmaps.
