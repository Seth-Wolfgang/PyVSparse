var indexSectionsWithContent =
{
  0: "abcdefgimnoprstuvw~",
  1: "isv",
  2: "civ",
  3: "abcdegimnoprstuvw~",
  4: "acefgimo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

