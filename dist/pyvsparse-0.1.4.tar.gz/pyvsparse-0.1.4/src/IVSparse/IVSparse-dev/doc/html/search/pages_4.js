var searchData=
[
  ['getting_20started_194',['Getting Started',['../getting_started.html',1,'']]]
];
