var hierarchy =
[
    [ "SparseMatrix< T, indexT, compressionLevel, columnMajor >::InnerIterator< T, indexT, compressionLevel, columnMajor >", "class_i_v_sparse_1_1_sparse_matrix_1_1_inner_iterator.html", null ],
    [ "SparseMatrix< T, indexT, 1, columnMajor >::InnerIterator", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4_1_1_inner_iterator.html", null ],
    [ "SparseMatrixBase", "class_i_v_sparse_1_1_sparse_matrix_base.html", [
      [ "SparseMatrix< T, indexT, compressionLevel, columnMajor >", "class_i_v_sparse_1_1_sparse_matrix.html", null ],
      [ "SparseMatrix< T, indexT, 1, columnMajor >", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4.html", null ],
      [ "SparseMatrix< T, indexT, 2, columnMajor >", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_012_00_01column_major_01_4.html", null ]
    ] ],
    [ "SparseMatrix< T, indexT, compressionLevel, columnMajor >::Vector", "class_i_v_sparse_1_1_sparse_matrix_1_1_vector.html", null ],
    [ "SparseMatrix< T, indexT, 1, columnMajor >::Vector", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4_1_1_vector.html", null ],
    [ "SparseMatrix< T, indexT, 2, columnMajor >::Vector", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_012_00_01column_major_01_4_1_1_vector.html", null ]
];