var searchData=
[
  ['matrix_20getters_196',['Matrix Getters',['../matrix_getters.html',1,'examples']]],
  ['matrix_20manipulation_20examples_197',['Matrix Manipulation Examples',['../manipulation_examples.html',1,'examples']]]
];
