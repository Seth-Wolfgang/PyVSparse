var annotated_dup =
[
    [ "IVSparse", null, [
      [ "SparseMatrix< T, indexT, 1, columnMajor >", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4.html", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4" ],
      [ "SparseMatrix", "class_i_v_sparse_1_1_sparse_matrix.html", "class_i_v_sparse_1_1_sparse_matrix" ],
      [ "SparseMatrixBase", "class_i_v_sparse_1_1_sparse_matrix_base.html", "class_i_v_sparse_1_1_sparse_matrix_base" ],
      [ "SparseMatrix< T, indexT, 2, columnMajor >", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_012_00_01column_major_01_4.html", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_012_00_01column_major_01_4" ]
    ] ]
];