var files_dup =
[
    [ "CSC_BLAS.hpp", "_c_s_c___b_l_a_s_8hpp.html", null ],
    [ "CSC_Constructors.hpp", "_c_s_c___constructors_8hpp.html", null ],
    [ "CSC_Iterator.hpp", "_c_s_c___iterator_8hpp.html", [
      [ "InnerIterator", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4_1_1_inner_iterator.html", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4_1_1_inner_iterator" ]
    ] ],
    [ "CSC_Iterator_Methods.hpp", "_c_s_c___iterator___methods_8hpp.html", null ],
    [ "CSC_Methods.hpp", "_c_s_c___methods_8hpp.html", null ],
    [ "CSC_Operators.hpp", "_c_s_c___operators_8hpp.html", null ],
    [ "CSC_Private_Methods.hpp", "_c_s_c___private___methods_8hpp.html", null ],
    [ "CSC_SparseMatrix.hpp", "_c_s_c___sparse_matrix_8hpp.html", [
      [ "SparseMatrix< T, indexT, 1, columnMajor >", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4.html", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4" ]
    ] ],
    [ "CSC_Vector.hpp", "_c_s_c___vector_8hpp.html", [
      [ "Vector", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4_1_1_vector.html", "class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_011_00_01column_major_01_4_1_1_vector" ]
    ] ],
    [ "CSC_Vector_Methods.hpp", "_c_s_c___vector___methods_8hpp.html", null ],
    [ "IVCSC_BLAS.hpp", "_i_v_c_s_c___b_l_a_s_8hpp_source.html", null ],
    [ "IVCSC_Constructors.hpp", "_i_v_c_s_c___constructors_8hpp_source.html", null ],
    [ "IVCSC_Iterator.hpp", "_i_v_c_s_c___iterator_8hpp_source.html", null ],
    [ "IVCSC_Iterator_Methods.hpp", "_i_v_c_s_c___iterator___methods_8hpp_source.html", null ],
    [ "IVCSC_Methods.hpp", "_i_v_c_s_c___methods_8hpp_source.html", null ],
    [ "IVCSC_Operators.hpp", "_i_v_c_s_c___operators_8hpp_source.html", null ],
    [ "IVCSC_Private_Methods.hpp", "_i_v_c_s_c___private___methods_8hpp_source.html", null ],
    [ "IVCSC_SparseMatrix.hpp", "_i_v_c_s_c___sparse_matrix_8hpp_source.html", null ],
    [ "IVCSC_Vector.hpp", "_i_v_c_s_c___vector_8hpp_source.html", null ],
    [ "IVCSC_Vector_Methods.hpp", "_i_v_c_s_c___vector___methods_8hpp_source.html", null ],
    [ "IVSparse_Base_Methods.hpp", "_i_v_sparse___base___methods_8hpp_source.html", null ],
    [ "IVSparse_SparseMatrixBase.hpp", "_i_v_sparse___sparse_matrix_base_8hpp_source.html", null ],
    [ "VCSC_BLAS.hpp", "_v_c_s_c___b_l_a_s_8hpp_source.html", null ],
    [ "VCSC_Constructors.hpp", "_v_c_s_c___constructors_8hpp_source.html", null ],
    [ "VCSC_Iterator.hpp", "_v_c_s_c___iterator_8hpp_source.html", null ],
    [ "VCSC_Iterator_Methods.hpp", "_v_c_s_c___iterator___methods_8hpp_source.html", null ],
    [ "VCSC_Methods.hpp", "_v_c_s_c___methods_8hpp_source.html", null ],
    [ "VCSC_Operators.hpp", "_v_c_s_c___operators_8hpp_source.html", null ],
    [ "VCSC_Private_Methods.hpp", "_v_c_s_c___private___methods_8hpp_source.html", null ],
    [ "VCSC_SparseMatrix.hpp", "_v_c_s_c___sparse_matrix_8hpp_source.html", null ],
    [ "VCSC_Vector.hpp", "_v_c_s_c___vector_8hpp_source.html", null ],
    [ "VCSC_Vector_Methods.hpp", "_v_c_s_c___vector___methods_8hpp_source.html", null ]
];