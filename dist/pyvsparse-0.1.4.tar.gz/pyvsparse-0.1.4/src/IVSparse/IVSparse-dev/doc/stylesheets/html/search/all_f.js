var searchData=
[
  ['uniquevals_69',['uniqueVals',['../class_i_v_sparse_1_1_sparse_matrix_3_01_t_00_01index_t_00_012_00_01column_major_01_4_1_1_vector.html#ab43699781e4c61dd4accec2a9dc554ed',1,'IVSparse::SparseMatrix&lt; T, indexT, 2, columnMajor &gt;::Vector']]]
];
